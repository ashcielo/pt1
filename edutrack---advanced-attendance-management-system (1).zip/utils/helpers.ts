
import { AttendanceRecord, Student } from '../types';

export const isWeekend = (date: Date): boolean => {
  const day = date.getDay();
  return day === 0 || day === 6; // 0 is Sunday, 6 is Saturday
};

export const formatDate = (date: Date): string => {
  return date.toISOString().split('T')[0];
};

export const downloadCSV = (data: any[], filename: string) => {
  if (data.length === 0) return;
  const headers = Object.keys(data[0]).join(',');
  const rows = data.map(obj => Object.values(obj).join(',')).join('\n');
  const csvContent = `data:text/csv;charset=utf-8,${headers}\n${rows}`;
  const encodedUri = encodeURI(csvContent);
  const link = document.createElement("a");
  link.setAttribute("href", encodedUri);
  link.setAttribute("download", filename);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
};

export const calculateAttendanceStats = (attendance: AttendanceRecord[], students: Student[]) => {
  const total = students.length;
  if (total === 0) return { percentage: 0, present: 0, absent: 0 };
  
  const today = formatDate(new Date());
  const todayRecords = attendance.filter(r => r.date === today);
  const present = todayRecords.filter(r => r.status === 'PRESENT').length;
  const absent = todayRecords.filter(r => r.status === 'ABSENT').length;
  
  return {
    percentage: Math.round((present / total) * 100) || 0,
    present,
    absent,
    total
  };
};
