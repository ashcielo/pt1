
import React, { useState } from 'react';
import { User, Student, AttendanceRecord, Holiday, UserRole } from '../types';
import { DashboardCard } from '../components/DashboardCard';
import { 
  Users, 
  GraduationCap, 
  TrendingUp, 
  Sparkles, 
  Download,
  CalendarDays,
  PieChart as PieIcon
} from 'lucide-react';
import { calculateAttendanceStats, downloadCSV } from '../utils/helpers';
import { getAttendanceInsights } from '../services/geminiService';
import { 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, 
  PieChart, Pie, Cell, AreaChart, Area 
} from 'recharts';

interface AdminDashboardProps {
  users: User[];
  students: Student[];
  attendance: AttendanceRecord[];
  holidays: Holiday[];
}

const COLORS = ['#10b981', '#f43f5e', '#6366f1', '#f59e0b'];

const AdminDashboard: React.FC<AdminDashboardProps> = ({ users, students, attendance, holidays }) => {
  const stats = calculateAttendanceStats(attendance, students);
  const [aiReport, setAiReport] = useState<string | null>(null);
  const [isGenerating, setIsGenerating] = useState(false);

  const teacherList = users.filter(u => u.role === UserRole.TEACHER);

  const generateAIInsight = async () => {
    setIsGenerating(true);
    const summary = {
      totalStudents: students.length,
      totalTeachers: teacherList.length,
      attendancePercentage: stats.percentage,
      presentToday: stats.present,
      absentToday: stats.absent
    };
    const insight = await getAttendanceInsights(summary);
    setAiReport(insight);
    setIsGenerating(false);
  };

  const pieData = [
    { name: 'Present', value: stats.present || 0 },
    { name: 'Absent', value: stats.absent || 0 },
  ];

  // Mock trend data for visualization
  const trendData = [
    { day: 'Mon', rate: 85 },
    { day: 'Tue', rate: 88 },
    { day: 'Wed', rate: 92 },
    { day: 'Thu', rate: 87 },
    { day: 'Fri', rate: stats.percentage },
  ];

  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <DashboardCard 
          title="Total Students" 
          value={students.length} 
          icon={<GraduationCap className="text-blue-600" size={24} />} 
          color="bg-blue-50"
        />
        <DashboardCard 
          title="Total Teachers" 
          value={teacherList.length} 
          icon={<Users className="text-indigo-600" size={24} />} 
          color="bg-indigo-50"
        />
        <DashboardCard 
          title="Attendance Today" 
          value={`${stats.percentage}%`} 
          icon={<TrendingUp className="text-emerald-600" size={24} />} 
          trend="+2.1%"
          trendUp={true}
          color="bg-emerald-50"
        />
        <DashboardCard 
          title="Active Holidays" 
          value={holidays.length} 
          icon={<CalendarDays className="text-amber-600" size={24} />} 
          color="bg-amber-50"
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 space-y-8">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
             {/* Pie Chart Representation */}
             <div className="bg-white p-6 rounded-3xl border border-gray-100 shadow-sm">
                <h3 className="text-lg font-bold text-gray-800 mb-4 flex items-center gap-2">
                  <PieIcon size={18} className="text-indigo-600" /> Today's Split
                </h3>
                <div className="h-64">
                   <ResponsiveContainer width="100%" height="100%">
                      <PieChart>
                        <Pie
                          data={pieData}
                          innerRadius={60}
                          outerRadius={80}
                          paddingAngle={5}
                          dataKey="value"
                        >
                          {pieData.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                          ))}
                        </Pie>
                        <Tooltip />
                      </PieChart>
                   </ResponsiveContainer>
                </div>
                <div className="flex justify-center gap-6 mt-4">
                  <div className="flex items-center gap-2"><div className="w-3 h-3 rounded-full bg-emerald-500"></div> <span className="text-xs font-bold text-gray-500">Present</span></div>
                  <div className="flex items-center gap-2"><div className="w-3 h-3 rounded-full bg-red-500"></div> <span className="text-xs font-bold text-gray-500">Absent</span></div>
                </div>
             </div>

             {/* Attendance Trend */}
             <div className="bg-white p-6 rounded-3xl border border-gray-100 shadow-sm">
                <h3 className="text-lg font-bold text-gray-800 mb-4 flex items-center gap-2">
                  <TrendingUp size={18} className="text-indigo-600" /> 5-Day Trend
                </h3>
                <div className="h-64">
                   <ResponsiveContainer width="100%" height="100%">
                      <AreaChart data={trendData}>
                        <defs>
                          <linearGradient id="colorRate" x1="0" y1="0" x2="0" y2="1">
                            <stop offset="5%" stopColor="#6366f1" stopOpacity={0.1}/>
                            <stop offset="95%" stopColor="#6366f1" stopOpacity={0}/>
                          </linearGradient>
                        </defs>
                        <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f3f4f6" />
                        <XAxis dataKey="day" axisLine={false} tickLine={false} />
                        <YAxis axisLine={false} tickLine={false} />
                        <Tooltip />
                        <Area type="monotone" dataKey="rate" stroke="#6366f1" fillOpacity={1} fill="url(#colorRate)" strokeWidth={3} />
                      </AreaChart>
                   </ResponsiveContainer>
                </div>
             </div>
          </div>

          <div className="bg-white p-8 rounded-3xl border border-gray-100 shadow-sm">
            <div className="flex justify-between items-center mb-8">
              <h2 className="text-xl font-bold text-gray-800">Weekly Performance</h2>
              <div className="bg-gray-50 px-3 py-1 rounded-lg text-xs font-bold text-gray-500 uppercase">System Active</div>
            </div>
            <div className="h-72 w-full">
               <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={trendData}>
                    <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f3f4f6" />
                    <XAxis dataKey="day" axisLine={false} tickLine={false} />
                    <YAxis axisLine={false} tickLine={false} />
                    <Tooltip />
                    <Bar dataKey="rate" fill="#6366f1" radius={[4, 4, 0, 0]} barSize={40} />
                  </BarChart>
               </ResponsiveContainer>
            </div>
          </div>
        </div>

        <div className="space-y-8">
          <div className="bg-indigo-900 text-white p-8 rounded-3xl shadow-xl relative overflow-hidden">
            <div className="absolute top-0 right-0 p-4 opacity-10">
              <Sparkles size={120} />
            </div>
            <h2 className="text-xl font-bold mb-4 flex items-center gap-2">
              <Sparkles className="text-indigo-300" size={24} /> AI Analysis
            </h2>
            <p className="text-indigo-200 text-sm mb-8 leading-relaxed">
              Get an AI-powered summary of institutional performance and student engagement.
            </p>
            <button 
              onClick={generateAIInsight}
              disabled={isGenerating}
              className="w-full bg-indigo-500 hover:bg-indigo-400 disabled:bg-indigo-800 py-3 rounded-xl font-bold transition-all flex items-center justify-center gap-2"
            >
              {isGenerating ? 'Analyzing...' : 'Generate Report'}
            </button>

            {aiReport && (
              <div className="mt-8 p-4 bg-indigo-800/50 rounded-2xl text-xs border border-indigo-700/50 animate-in fade-in slide-in-from-top-4">
                <div className="prose prose-invert prose-sm">
                   {aiReport.substring(0, 300)}...
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default AdminDashboard;
