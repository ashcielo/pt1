
import React, { useState, useMemo } from 'react';
import { User, Student, AttendanceRecord, Holiday } from '../types';
import { DashboardCard } from '../components/DashboardCard';
import { GraduationCap, CheckCircle2, XCircle, Calendar, Smartphone, ShieldCheck, Download } from 'lucide-react';
import { formatDate, isWeekend, downloadCSV } from '../utils/helpers';

interface AttendanceTakerProps {
  user: User;
  students: Student[];
  setStudents: React.Dispatch<React.SetStateAction<Student[]>>;
  attendance: AttendanceRecord[];
  setAttendance: React.Dispatch<React.SetStateAction<AttendanceRecord[]>>;
  holidays: Holiday[];
}

const AttendanceTaker: React.FC<AttendanceTakerProps> = ({ user, students, setStudents, attendance, setAttendance, holidays }) => {
  const [selectedClass, setSelectedClass] = useState(user.assignedClasses?.[0] || '');
  const [activeDate, setActiveDate] = useState(formatDate(new Date()));
  const [showOtpModal, setShowOtpModal] = useState<string | null>(null);

  const filteredStudents = useMemo(() => 
    students.filter(s => s.classSection === selectedClass),
  [students, selectedClass]);

  const stats = useMemo(() => {
    const todayRecords = attendance.filter(r => r.date === activeDate && r.classSection === selectedClass);
    return {
      total: filteredStudents.length,
      present: todayRecords.filter(r => r.status === 'PRESENT').length,
      absent: todayRecords.filter(r => r.status === 'ABSENT').length,
    };
  }, [attendance, activeDate, selectedClass, filteredStudents]);

  const toggleAttendance = (studentId: string, status: 'PRESENT' | 'ABSENT') => {
    setAttendance(prev => {
      const otherRecords = prev.filter(r => !(r.studentId === studentId && r.date === activeDate));
      return [...otherRecords, { studentId, status, date: activeDate, classSection: selectedClass }];
    });
  };

  const getStatus = (studentId: string) => {
    return attendance.find(r => r.studentId === studentId && r.date === activeDate)?.status;
  };

  const handleVerify = (id: string) => {
    setShowOtpModal(id);
  };

  const confirmOtp = () => {
    if (showOtpModal) {
      setStudents(prev => prev.map(s => s.id === showOtpModal ? { ...s, isVerified: true } : s));
      setShowOtpModal(null);
    }
  };

  const handleExport = () => {
    const reportData = filteredStudents.map(s => ({
      RegNo: s.regNumber,
      Name: s.name,
      Class: s.classSection,
      Status: getStatus(s.id) || 'PENDING'
    }));
    downloadCSV(reportData, `attendance_${selectedClass}_${activeDate}.csv`);
  };

  const isHoliday = isWeekend(new Date(activeDate)) || holidays.some(h => h.date === activeDate);

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex items-center gap-4 bg-white p-2 pr-6 rounded-2xl border shadow-sm w-fit">
          <div className="bg-indigo-100 text-indigo-700 px-4 py-2 rounded-xl font-bold">
            {selectedClass}
          </div>
          <select 
            value={selectedClass} 
            onChange={(e) => setSelectedClass(e.target.value)}
            className="bg-transparent font-semibold focus:outline-none"
          >
            {user.assignedClasses?.map(c => <option key={c} value={c}>{c}</option>)}
          </select>
        </div>

        <div className="flex items-center gap-4">
          <input 
            type="date" 
            value={activeDate}
            onChange={(e) => setActiveDate(e.target.value)}
            className="px-4 py-2 bg-white border border-gray-200 rounded-xl shadow-sm focus:ring-2 focus:ring-indigo-500 outline-none font-medium"
          />
          <button onClick={handleExport} className="flex items-center gap-2 px-6 py-2 bg-indigo-600 text-white rounded-xl font-bold shadow-lg shadow-indigo-100 hover:bg-indigo-700 transition-all">
            <Download size={18} /> Export Current View
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <DashboardCard 
          title="Class Strength" 
          value={stats.total} 
          icon={<GraduationCap className="text-blue-600" size={24} />} 
          color="bg-blue-50"
        />
        <DashboardCard 
          title="Marked Present" 
          value={stats.present} 
          icon={<CheckCircle2 className="text-emerald-600" size={24} />} 
          color="bg-emerald-50"
        />
        <DashboardCard 
          title="Marked Absent" 
          value={stats.absent} 
          icon={<XCircle className="text-red-600" size={24} />} 
          color="bg-red-50"
        />
      </div>

      <div className="bg-white rounded-3xl border border-gray-100 shadow-sm overflow-hidden">
        {isHoliday ? (
          <div className="p-20 text-center space-y-4">
            <div className="flex justify-center">
              <div className="bg-amber-50 p-6 rounded-full text-amber-500">
                <Calendar size={64} />
              </div>
            </div>
            <h2 className="text-2xl font-bold text-gray-800">Relax, it's a Holiday!</h2>
            <p className="text-gray-500 max-w-sm mx-auto">No attendance marking required for weekends or school holidays.</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left">
              <thead>
                <tr className="bg-gray-50/50 text-gray-400 text-xs font-bold uppercase tracking-wider">
                  <th className="py-6 px-8">Student Info</th>
                  <th className="py-6 px-8">Verification</th>
                  <th className="py-6 px-8 text-center">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-50">
                {filteredStudents.map(student => (
                  <tr key={student.id} className="hover:bg-indigo-50/30 transition-colors">
                    <td className="py-6 px-8">
                      <div className="flex items-center gap-4">
                        <div className="w-10 h-10 rounded-full bg-gray-100 flex items-center justify-center text-gray-500 font-bold uppercase">
                          {student.name.charAt(0)}
                        </div>
                        <div>
                          <div className="font-bold text-gray-900">{student.name}</div>
                          <div className="text-xs text-gray-500 font-medium">{student.regNumber}</div>
                        </div>
                      </div>
                    </td>
                    <td className="py-6 px-8">
                      {student.isVerified ? (
                        <div className="flex items-center gap-2 text-emerald-600 bg-emerald-50 px-3 py-1 rounded-full w-fit">
                          <ShieldCheck size={14} />
                          <span className="text-xs font-bold">Verified</span>
                        </div>
                      ) : (
                        <button 
                          onClick={() => handleVerify(student.id)}
                          className="flex items-center gap-2 text-amber-600 bg-amber-50 hover:bg-amber-100 px-3 py-1 rounded-full w-fit transition-colors"
                        >
                          <Smartphone size={14} />
                          <span className="text-xs font-bold">Verify OTP</span>
                        </button>
                      )}
                    </td>
                    <td className="py-6 px-8">
                      <div className="flex justify-center gap-3">
                        <button 
                          onClick={() => toggleAttendance(student.id, 'PRESENT')}
                          className={`flex items-center gap-2 px-6 py-2 rounded-xl font-bold transition-all ${
                            getStatus(student.id) === 'PRESENT' 
                              ? 'bg-emerald-600 text-white shadow-lg shadow-emerald-200' 
                              : 'bg-white text-gray-400 border border-gray-100 hover:border-emerald-200 hover:text-emerald-500'
                          }`}
                        >
                          Present
                        </button>
                        <button 
                          onClick={() => toggleAttendance(student.id, 'ABSENT')}
                          className={`flex items-center gap-2 px-6 py-2 rounded-xl font-bold transition-all ${
                            getStatus(student.id) === 'ABSENT' 
                              ? 'bg-red-500 text-white shadow-lg shadow-red-200' 
                              : 'bg-white text-gray-400 border border-gray-100 hover:border-red-200 hover:text-red-400'
                          }`}
                        >
                          Absent
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {showOtpModal && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-50 flex items-center justify-center p-6">
          <div className="bg-white max-w-sm w-full rounded-3xl p-10 text-center animate-in zoom-in-95 duration-200 shadow-2xl">
            <div className="flex justify-center mb-6">
               <div className="bg-indigo-50 p-4 rounded-2xl text-indigo-600">
                  <Smartphone size={32} />
               </div>
            </div>
            <h3 className="text-2xl font-bold text-gray-900 mb-2">OTP Verification</h3>
            <p className="text-gray-500 mb-8 text-sm">
              Confirming student identity for academic record security.
            </p>
            <button 
              onClick={confirmOtp}
              className="w-full bg-indigo-600 text-white font-bold py-4 rounded-xl hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-200"
            >
              Confirm Verification
            </button>
            <button onClick={() => setShowOtpModal(null)} className="w-full mt-4 text-gray-400 font-semibold text-sm hover:text-gray-600">
              Cancel
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default AttendanceTaker;
