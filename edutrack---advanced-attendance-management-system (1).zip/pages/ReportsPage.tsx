
import React, { useState, useMemo } from 'react';
import { AttendanceRecord, Student } from '../types';
import { FileSpreadsheet, FileText, Printer, Search, Download, ChevronRight, GraduationCap } from 'lucide-react';
import { downloadCSV, formatDate } from '../utils/helpers';

interface ReportsPageProps {
  attendance: AttendanceRecord[];
  students: Student[];
  classes: string[];
}

const ReportsPage: React.FC<ReportsPageProps> = ({ attendance, students, classes }) => {
  const [selectedClass, setSelectedClass] = useState<string>(classes[0] || '');
  const [dateRange, setDateRange] = useState({
    start: formatDate(new Date(new Date().setDate(new Date().getDate() - 7))),
    end: formatDate(new Date())
  });

  const reportData = useMemo(() => {
    return students
      .filter(s => s.classSection === selectedClass)
      .map(student => {
        const studentAttendance = attendance.filter(a => 
          a.studentId === student.id && 
          a.date >= dateRange.start && 
          a.date <= dateRange.end
        );
        
        const total = studentAttendance.length;
        const present = studentAttendance.filter(a => a.status === 'PRESENT').length;
        const absent = studentAttendance.filter(a => a.status === 'ABSENT').length;
        const percentage = total > 0 ? Math.round((present / total) * 100) : 0;

        return {
          id: student.id,
          name: student.name,
          reg: student.regNumber,
          present,
          absent,
          total,
          percentage
        };
      });
  }, [attendance, students, selectedClass, dateRange]);

  const handleExportExcel = () => {
    const csvData = reportData.map(r => ({
      'Register No': r.reg,
      'Student Name': r.name,
      'Present Days': r.present,
      'Absent Days': r.absent,
      'Total Sessions': r.total,
      'Attendance %': `${r.percentage}%`
    }));
    downloadCSV(csvData, `Attendance_Report_${selectedClass}_${dateRange.start}_to_${dateRange.end}.csv`);
  };

  const handlePrintPDF = () => {
    window.print();
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      {/* Header & Controls - Hidden on Print */}
      <div className="print:hidden bg-white p-8 rounded-3xl border border-gray-100 shadow-sm space-y-6">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div>
            <h2 className="text-2xl font-bold text-gray-900">Attendance Reports</h2>
            <p className="text-gray-500 text-sm mt-1">Generate and convert academic reports to Excel or PDF</p>
          </div>
          <div className="flex gap-3">
             <button 
               onClick={handleExportExcel}
               className="flex items-center gap-2 bg-emerald-600 text-white px-5 py-3 rounded-xl font-bold shadow-lg shadow-emerald-100 hover:bg-emerald-700 transition-all"
             >
               <FileSpreadsheet size={18} /> Convert to Excel
             </button>
             <button 
               onClick={handlePrintPDF}
               className="flex items-center gap-2 bg-indigo-600 text-white px-5 py-3 rounded-xl font-bold shadow-lg shadow-indigo-100 hover:bg-indigo-700 transition-all"
             >
               <Printer size={18} /> Print as PDF
             </button>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 pt-6 border-t border-gray-50">
          <div>
            <label className="block text-xs font-bold text-gray-400 uppercase tracking-widest mb-2">Select Class</label>
            <select 
              value={selectedClass} 
              onChange={e => setSelectedClass(e.target.value)}
              className="w-full bg-gray-50 border border-gray-100 rounded-xl px-4 py-3 font-semibold focus:ring-2 focus:ring-indigo-500 outline-none"
            >
              {classes.map(c => <option key={c} value={c}>{c}</option>)}
            </select>
          </div>
          <div>
            <label className="block text-xs font-bold text-gray-400 uppercase tracking-widest mb-2">Start Date</label>
            <input 
              type="date" 
              value={dateRange.start}
              onChange={e => setDateRange({...dateRange, start: e.target.value})}
              className="w-full bg-gray-50 border border-gray-100 rounded-xl px-4 py-3 font-semibold focus:ring-2 focus:ring-indigo-500 outline-none"
            />
          </div>
          <div>
            <label className="block text-xs font-bold text-gray-400 uppercase tracking-widest mb-2">End Date</label>
            <input 
              type="date" 
              value={dateRange.end}
              onChange={e => setDateRange({...dateRange, end: e.target.value})}
              className="w-full bg-gray-50 border border-gray-100 rounded-xl px-4 py-3 font-semibold focus:ring-2 focus:ring-indigo-500 outline-none"
            />
          </div>
        </div>
      </div>

      {/* Report Content - Visible on Print */}
      <div className="bg-white rounded-3xl border border-gray-100 shadow-sm overflow-hidden print:border-none print:shadow-none">
        <div className="p-8 border-b hidden print:block">
           <h1 className="text-2xl font-black text-indigo-900">EduTrack Official Report</h1>
           <div className="text-sm text-gray-500 mt-2 flex justify-between">
              <span>Class: {selectedClass}</span>
              <span>Period: {dateRange.start} to {dateRange.end}</span>
           </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead>
              <tr className="bg-gray-50/50 text-gray-400 text-[10px] font-bold uppercase tracking-wider">
                <th className="py-6 px-8">Register No</th>
                <th className="py-6 px-8">Student Name</th>
                <th className="py-6 px-8 text-center">Present</th>
                <th className="py-6 px-8 text-center">Absent</th>
                <th className="py-6 px-8 text-center">Status %</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-50">
              {reportData.map(student => (
                <tr key={student.id} className="hover:bg-gray-50/50 transition-colors print:bg-white">
                  <td className="py-5 px-8 font-mono text-xs font-bold text-indigo-600">{student.reg}</td>
                  <td className="py-5 px-8">
                    <span className="font-bold text-gray-900">{student.name}</span>
                  </td>
                  <td className="py-5 px-8 text-center">
                    <span className="text-emerald-600 font-bold">{student.present}</span>
                  </td>
                  <td className="py-5 px-8 text-center">
                    <span className="text-red-500 font-bold">{student.absent}</span>
                  </td>
                  <td className="py-5 px-8">
                    <div className="flex flex-col items-center gap-1">
                      <div className="w-full max-w-[80px] h-1.5 bg-gray-100 rounded-full overflow-hidden">
                        <div 
                          className={`h-full rounded-full ${student.percentage > 75 ? 'bg-emerald-500' : 'bg-amber-500'}`}
                          style={{ width: `${student.percentage}%` }}
                        ></div>
                      </div>
                      <span className="text-[10px] font-black text-gray-600">{student.percentage}%</span>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          {reportData.length === 0 && (
            <div className="p-20 text-center print:hidden">
              <FileText size={48} className="mx-auto text-gray-200 mb-4" />
              <p className="text-gray-400 font-medium">No records found for the selected range.</p>
            </div>
          )}
        </div>
      </div>

      <style>{`
        @media print {
          body * { visibility: hidden; }
          .print-area, .print-area * { visibility: visible; }
          .print-area { position: absolute; left: 0; top: 0; width: 100%; }
          aside, header, button, .print\\:hidden { display: none !important; }
          main { display: block !important; padding: 0 !important; }
          .bg-white { border: none !important; shadow: none !important; }
          table { width: 100% !important; border-collapse: collapse !important; }
          th, td { border-bottom: 1px solid #eee !important; padding: 12px 20px !important; }
        }
      `}</style>
    </div>
  );
};

export default ReportsPage;
