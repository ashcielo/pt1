
import { GoogleGenAI } from "@google/genai";

export const getAttendanceInsights = async (attendanceData: any) => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  
  const prompt = `
    Analyze this student attendance data and provide a concise professional report for the Academic Director.
    Data Summary: ${JSON.stringify(attendanceData)}
    
    Include:
    1. Overall attendance rate.
    2. Classes that need attention.
    3. Suggested interventions.
    4. Notable trends.
    Keep the response in a structured markdown format.
  `;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: prompt,
    });
    return response.text;
  } catch (error) {
    console.error("Gemini Error:", error);
    return "Failed to generate AI insights. Please check your connection.";
  }
};
