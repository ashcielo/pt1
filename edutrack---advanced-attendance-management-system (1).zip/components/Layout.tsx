
import React from 'react';
import { User, UserRole } from '../types';
import { 
  LayoutDashboard, 
  Users, 
  GraduationCap, 
  Calendar, 
  LogOut, 
  ShieldCheck, 
  FileSpreadsheet, 
  Bell 
} from 'lucide-react';

interface LayoutProps {
  user: User;
  onLogout: () => void;
  activeView: string;
  onViewChange: (view: string) => void;
  children: React.ReactNode;
}

export const Layout: React.FC<LayoutProps> = ({ user, onLogout, activeView, onViewChange, children }) => {
  return (
    <div className="flex h-screen bg-gray-50 overflow-hidden">
      {/* Sidebar - Hidden on Print */}
      <aside className="hidden md:flex flex-col w-64 bg-slate-900 text-white p-6 print:hidden">
        <div className="flex items-center gap-3 mb-10 px-2">
          <div className="bg-indigo-600 p-2 rounded-lg">
            <ShieldCheck size={24} />
          </div>
          <span className="text-xl font-bold tracking-tight">EduTrack</span>
        </div>

        <nav className="flex-1 space-y-1">
          <NavLink 
            icon={<LayoutDashboard size={20} />} 
            label="Dashboard" 
            active={activeView === 'dashboard'} 
            onClick={() => onViewChange('dashboard')}
          />
          {user.role === UserRole.ADMIN ? (
            <>
              <NavLink 
                icon={<Users size={20} />} 
                label="Teachers" 
                active={activeView === 'teachers'} 
                onClick={() => onViewChange('teachers')}
              />
              <NavLink 
                icon={<GraduationCap size={20} />} 
                label="Student Masters" 
                active={activeView === 'students'} 
                onClick={() => onViewChange('students')}
              />
            </>
          ) : (
            <>
              <NavLink 
                icon={<Calendar size={20} />} 
                label="Take Attendance" 
                active={activeView === 'attendance'} 
                onClick={() => onViewChange('attendance')}
              />
              <NavLink 
                icon={<GraduationCap size={20} />} 
                label="My Students" 
                active={activeView === 'my-students'} 
                onClick={() => onViewChange('my-students')}
              />
            </>
          )}
          <NavLink 
            icon={<FileSpreadsheet size={20} />} 
            label="Reports" 
            active={activeView === 'reports'} 
            onClick={() => onViewChange('reports')}
          />
        </nav>

        <div className="mt-auto pt-6 border-t border-slate-800">
          <button 
            onClick={onLogout}
            className="flex items-center gap-3 w-full px-4 py-3 rounded-lg hover:bg-red-500/10 hover:text-red-400 transition-colors"
          >
            <LogOut size={20} />
            <span className="font-medium">Sign Out</span>
          </button>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 flex flex-col min-w-0 overflow-hidden">
        {/* Top Navbar - Hidden on Print */}
        <header className="h-16 bg-white border-b flex items-center justify-between px-8 shrink-0 print:hidden">
          <div>
            <h1 className="text-xl font-semibold text-gray-800">Welcome, {user.name}</h1>
            <p className="text-xs text-gray-500 uppercase tracking-wider font-semibold">
              {user.role} {user.role === UserRole.TEACHER && `• ${user.assignedClasses?.join(', ')}`}
            </p>
          </div>
          <div className="flex items-center gap-4">
            <button className="p-2 text-gray-400 hover:text-indigo-600 relative">
              <Bell size={20} />
              <span className="absolute top-2 right-2 w-2 h-2 bg-red-500 rounded-full border-2 border-white"></span>
            </button>
            <div className="flex items-center gap-3 pl-4 border-l">
              <div className="w-9 h-9 rounded-full bg-indigo-100 flex items-center justify-center text-indigo-700 font-bold uppercase">
                {user.name.charAt(0)}
              </div>
            </div>
          </div>
        </header>

        {/* Content Area */}
        <div className="flex-1 overflow-y-auto p-8 print:p-0">
          <div className="max-w-7xl mx-auto print:max-w-full">
            {children}
          </div>
        </div>
      </main>
    </div>
  );
};

interface NavLinkProps {
  icon: React.ReactNode;
  label: string;
  active?: boolean;
  onClick: () => void;
}

const NavLink: React.FC<NavLinkProps> = ({ icon, label, active = false, onClick }) => (
  <button 
    onClick={(e) => {
      e.preventDefault();
      onClick();
    }}
    className={`flex items-center gap-3 w-full px-4 py-3 rounded-xl transition-all ${
      active ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-600/20' : 'text-slate-400 hover:text-white hover:bg-slate-800'
    }`}
  >
    {icon}
    <span className="font-medium">{label}</span>
  </button>
);
