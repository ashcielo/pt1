
import React, { useState } from 'react';
import { Student } from '../types';
import { Plus, Search, Edit2, Trash2, X, GraduationCap, Smartphone } from 'lucide-react';

interface StudentManagerProps {
  students: Student[];
  setStudents: React.Dispatch<React.SetStateAction<Student[]>>;
  classes: string[];
  canChangeClass: boolean;
}

const StudentManager: React.FC<StudentManagerProps> = ({ students, setStudents, classes, canChangeClass }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [showModal, setShowModal] = useState(false);
  const [editingStudent, setEditingStudent] = useState<Student | null>(null);

  const [formData, setFormData] = useState({
    name: '',
    regNumber: '',
    email: '',
    phone: '',
    classSection: classes[0] || ''
  });

  const filteredStudents = students.filter(s => 
    (s.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
     s.regNumber.toLowerCase().includes(searchTerm.toLowerCase())) &&
    classes.includes(s.classSection)
  );

  const openAddModal = () => {
    setEditingStudent(null);
    setFormData({ name: '', regNumber: '', email: '', phone: '', classSection: classes[0] || '' });
    setShowModal(true);
  };

  const openEditModal = (student: Student) => {
    setEditingStudent(student);
    setFormData({ 
      name: student.name, 
      regNumber: student.regNumber, 
      email: student.email, 
      phone: student.phone, 
      classSection: student.classSection 
    });
    setShowModal(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (editingStudent) {
      setStudents(prev => prev.map(s => s.id === editingStudent.id ? { ...s, ...formData } : s));
    } else {
      const newStudent: Student = {
        ...formData,
        id: `s${Date.now()}`,
        isVerified: false
      };
      setStudents(prev => [...prev, newStudent]);
    }
    setShowModal(false);
  };

  const deleteStudent = (student: Student) => {
    const confirmation = window.confirm(
      `CRITICAL WARNING: You are about to delete ${student.name} (${student.regNumber}).\n\n` +
      `This will PERMANENTLY remove all of their basic data and historical attendance records from the system.\n\n` +
      `Are you sure you wish to proceed?`
    );
    if (confirmation) {
      setStudents(prev => prev.filter(s => s.id !== student.id));
    }
  };

  return (
    <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-300">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Student Masters</h2>
          <p className="text-gray-500 text-sm">Centralized database for student bio-data and class assignments</p>
        </div>
        <button 
          onClick={openAddModal}
          className="flex items-center gap-2 bg-indigo-600 text-white px-6 py-3 rounded-xl font-bold shadow-lg shadow-indigo-200 hover:bg-indigo-700 transition-all"
        >
          <Plus size={20} /> Add New Student
        </button>
      </div>

      <div className="bg-white p-4 rounded-2xl border border-gray-100 shadow-sm flex items-center gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400" size={18} />
          <input 
            type="text" 
            placeholder="Search by name or register number..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-12 pr-4 py-3 bg-gray-50 border-none rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none"
          />
        </div>
        <div className="text-sm font-medium text-gray-400 px-4 border-l hidden md:block">
          {filteredStudents.length} Students
        </div>
      </div>

      <div className="bg-white rounded-3xl border border-gray-100 shadow-sm overflow-hidden">
        <table className="w-full text-left border-collapse">
          <thead>
            <tr className="bg-gray-50/50 text-gray-400 text-xs font-bold uppercase tracking-wider">
              <th className="py-5 px-8">Student</th>
              <th className="py-5 px-8">Class</th>
              <th className="py-5 px-8">Contact</th>
              <th className="py-5 px-8 text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-50">
            {filteredStudents.map(student => (
              <tr key={student.id} className="group hover:bg-indigo-50/30 transition-colors">
                <td className="py-5 px-8">
                  <div className="flex items-center gap-4">
                    <div className="w-10 h-10 rounded-xl bg-indigo-100 text-indigo-700 flex items-center justify-center font-bold">
                      {student.name.charAt(0)}
                    </div>
                    <div>
                      <div className="font-bold text-gray-900">{student.name}</div>
                      <div className="text-xs text-gray-500 font-medium">{student.regNumber}</div>
                    </div>
                  </div>
                </td>
                <td className="py-5 px-8">
                  <span className="px-3 py-1 bg-white border border-gray-200 rounded-lg text-xs font-bold text-gray-600">
                    {student.classSection}
                  </span>
                </td>
                <td className="py-5 px-8">
                  <div className="text-xs text-gray-600 truncate max-w-[150px]">{student.email}</div>
                  <div className="text-[10px] text-gray-400">{student.phone}</div>
                </td>
                <td className="py-5 px-8 text-right">
                  <div className="flex justify-end gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                    <button onClick={() => openEditModal(student)} className="p-2 text-indigo-600 hover:bg-white rounded-lg">
                      <Edit2 size={16} />
                    </button>
                    <button onClick={() => deleteStudent(student)} className="p-2 text-red-500 hover:bg-white rounded-lg">
                      <Trash2 size={16} />
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {showModal && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-[100] flex items-center justify-center p-6">
          <div className="bg-white max-w-lg w-full rounded-3xl overflow-hidden animate-in zoom-in-95 duration-200 shadow-2xl">
            <div className="px-8 py-6 border-b flex justify-between items-center bg-gray-50/50">
              <h3 className="text-xl font-bold text-gray-900">{editingStudent ? 'Edit Student Record' : 'Enroll New Student'}</h3>
              <button onClick={() => setShowModal(false)} className="p-2 hover:bg-white rounded-full transition-colors">
                <X size={20} className="text-gray-400" />
              </button>
            </div>
            
            <form onSubmit={handleSubmit} className="p-8 space-y-5">
              <div className="grid grid-cols-2 gap-5">
                <div className="col-span-2">
                  <label className="block text-sm font-bold text-gray-700 mb-2">Full Name</label>
                  <input type="text" required value={formData.name} onChange={e => setFormData({...formData, name: e.target.value})} className="w-full px-4 py-3 bg-gray-50 border border-gray-100 rounded-xl outline-none focus:ring-2 focus:ring-indigo-500" />
                </div>
                <div>
                  <label className="block text-sm font-bold text-gray-700 mb-2">Reg Number</label>
                  <input type="text" required value={formData.regNumber} onChange={e => setFormData({...formData, regNumber: e.target.value})} className="w-full px-4 py-3 bg-gray-50 border border-gray-100 rounded-xl outline-none focus:ring-2 focus:ring-indigo-500" />
                </div>
                <div>
                  <label className="block text-sm font-bold text-gray-700 mb-2">Class Assignment</label>
                  <select disabled={!canChangeClass && editingStudent !== null} value={formData.classSection} onChange={e => setFormData({...formData, classSection: e.target.value})} className="w-full px-4 py-3 bg-gray-50 border border-gray-100 rounded-xl outline-none">
                    {classes.map(c => <option key={c} value={c}>{c}</option>)}
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-bold text-gray-700 mb-2">Email</label>
                  <input type="email" required value={formData.email} onChange={e => setFormData({...formData, email: e.target.value})} className="w-full px-4 py-3 bg-gray-50 border border-gray-100 rounded-xl outline-none" />
                </div>
                <div>
                  <label className="block text-sm font-bold text-gray-700 mb-2">Phone</label>
                  <input type="tel" required value={formData.phone} onChange={e => setFormData({...formData, phone: e.target.value})} className="w-full px-4 py-3 bg-gray-50 border border-gray-100 rounded-xl outline-none" />
                </div>
              </div>
              <div className="pt-4 flex gap-3">
                <button type="button" onClick={() => setShowModal(false)} className="flex-1 px-6 py-4 border border-gray-200 text-gray-500 font-bold rounded-2xl hover:bg-gray-50 transition-all">Cancel</button>
                <button type="submit" className="flex-1 px-6 py-4 bg-indigo-600 text-white font-bold rounded-2xl shadow-lg hover:bg-indigo-700 transition-all">Save Changes</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default StudentManager;
